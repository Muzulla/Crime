public class Court extends Crime{
	private String court_name;
	public Court(){

	}
	public Court(String address, String court_name){
		super(address);
		this.court_name = court_name;
	}
	public void setcourt_name(String court_name){
		this.court_name = court_name;
	}
	public String getcourt_name(){
		return court_name;
	}
	public String toString(){
		return super.toString()+"the court_name is"+court_name;
	}
	public static void main(String[] args) {
		Court naa = new Court();
		naa.setaddress("kikwajuni");
		naa.setcourt_name("kizimbani");
		System.out.println(naa.toString());
	}
}