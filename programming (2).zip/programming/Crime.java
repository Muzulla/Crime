public class Crime{
	private String address;
	public Crime(){

	}
	public Crime(String address){
		this.address = address;
	}
	public void setaddress(String address){
		this.address = address;
	}
	public String getaddress(){
		return address;
	}
	@Override
	public String toString(){
		return "the address is"+address;
	}
}