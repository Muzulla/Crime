public class Theft extends Crime{
	private int money;
	private String goods, childen;
	public theft(String address,int money,String goods,String childen){
		super(address);
		this.money = money;
		this.childen = childen;
		this.goods = goods;
	}
	public void setmoney(int money){
		this.money = money;
	}
	public String getmoney(){
		return money;
	}
	public void setchildren(String children){
		this.childen = children;
	}
	public String getchildren(){
		return children();
	}
	public void setgoodes(String goods){
		this.goodes = goods;
	}
	public String getgoods(){
		return goods;
	}
	public String toString(){
		return getaddress()+"the money is"+money+"the children name is"+children+"the goods is"+goods;
		public static void main(String[] args) {
			theft th = new theft();
			th.setaddress("mbweni");
				th.setmoney(2000);
				th.setchildren("mwajuma");
				th.set("banana");
				th.getaddress();
				System.out.println(naa.toString());
		}
	}
} 