public class Police extends Crime {
	private String Police_man;
	public Police(){

	}
	public Police(String address,String Police_man){
		super(address);
		this.Police_man = Police_man;
	}
	public void setpolice(String Police_man){
		this.Police_man = Police_man;
	}
	public String getPolice_man(){
		return Police_man;
	}
	public String toString(){
		return "the address is"+super.toString()+"and the police is"+Police_man;
	}
	public static void main(String[] args) {
		Police pm = new Police();
		pm.setaddress("kianga");
		pm.setpolice("nassra");
		//pm.getaddress();
		System.out.println(pm.toString());
	}
}