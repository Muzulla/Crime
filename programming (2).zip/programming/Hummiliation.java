//import java.util.Scanner;
public class Hummiliation extends Crime{
	private String rope;
	public Hummiliation(){

	}
	public Hummiliation(String address, String rope){
		super(address);
		this.rope = rope;
	}
		public void setrope(String rope){
			this.rope = rope;
		}
		public String getrope(){
			return rope;
		}
		public String toString(){
			return getaddress()+ "the rope name is" +rope;
		}
		public static void main(String[] args) {
			Hummiliation hm = new Hummiliation();
			//Scanner naa = new Scanner(System.in);
			hm.setaddress("kisauni");
			hm.setrope("ali");
			//hm.getaddress();
			//hm.getrope();
			//naa.getaddress();
			System.out.println(hm.toString());
	}
}
