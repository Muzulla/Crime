public class Drug_abuse extends Crime{
	private String sigarate;
	public Drug_abuse(){
		this.sigarate = sigarate;
	}
	public void setsigarate(String sigarate){
		this.sigarate = sigarate;

	}
	public Drug_abuse(String address, String sigarate){
		super(address);
	}
	public String getsigarate(){
		return sigarate;
	}
	public String toString(){
		return super.toString()+"and the drug_abuse is"+sigarate;
	}
	public static void main(String[] args){
		Drug_abuse da = new Drug_abuse();
		da.setaddress("pemba");
		da.setsigarate("alcohol");
		//naa.getaddress();
		System.out.println(da.toString());
	}
}