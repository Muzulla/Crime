public class Social_media extends Crime{
	private  String zbc;
	public Social_media(){

	}
	public Social_media(String address, String zbc){
		super(address);
		this.zbc = zbc;
	}
	public void setzbc(String zbc){
		this.zbc = zbc;
	}
	public String getzbc(){
		return zbc;
	}
	public String toString(){
		return super.toString()+"the media is  "+zbc;
	}
	@Override
	public static void main(String[] args) {
		Social_media sm = new Social_media();
		sm.setaddress("kizimkazi");
		sm.setzbc("wete");
		System.out.println(sm.toString());
	}
}